document.getElementById('fetchDataBtn').addEventListener('click', fetchData);

async function fetchData() {
    const apiUrl = 'https://api.example.com/data'; // Replace with your API endpoint
    const responseElement = document.getElementById('response');

    try {
        // Make the API call
        const response = await fetch(apiUrl, {
            method: 'GET', // Or POST, PUT, DELETE based on your API
            headers: {
                'Content-Type': 'application/json', // Adjust headers if necessary
                'Authorization': 'Bearer YOUR_TOKEN', // Optional, if your API requires authorization
            },
        });

        // Check if the response is OK
        if (!response.ok) {
            throw new Error(`Error: ${response.status}`);
        }

        // Parse the JSON data
        const data = await response.json();

        // Update the DOM with the response
        responseElement.textContent = JSON.stringify(data, null, 2);
    } catch (error) {
        console.error('Error fetching data:', error);
        responseElement.textContent = `Error: ${error.message}`;
    }
}
